
export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number; // Index of correct option
  feedback: string;
}

export interface LessonContent {
  title: string;
  sections: {
    heading: string;
    content: string;
    icon?: string;
    checkupQuestion?: Question; // New: Inline test yourself question
  }[];
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  iconName: string;
  content: LessonContent;
  preQuiz: Question[];
  postQuiz: Question[];
}

export interface UserProgress {
  lessons: {
    [lessonId: string]: {
      preQuizScore?: number;
      postQuizScore?: number;
      completed: boolean;
    };
  };
  activities: {
    phishing: boolean;
    network: boolean;
    crypto: boolean;
    access: boolean;
  };
}

export type ViewState = 
  | 'HOME' 
  | 'DASHBOARD' 
  | 'LESSON' 
  | 'ACTIVITY_PHISHING' 
  | 'ACTIVITY_NETWORK'
  | 'ACTIVITY_CRYPTO'
  | 'ACTIVITY_ACCESS';

export interface PhishingEmail {
  id: number;
  sender: string;
  subject: string;
  body: string;
  isPhishing: boolean;
  explanation: string;
  indicators: string[]; // List of suspicious indicators to highlight in explanation
}

export interface NetworkScenario {
  id: number;
  device: string;
  difficulty: 'Medium' | 'Hard' | 'Extreme';
  status: 'Vulnerable' | 'Secure' | 'Unknown';
  description: string;
  vulnerability?: string;
  solution?: string;
  options?: string[]; // Multiple choice fixes
  correctOption?: number;
}
