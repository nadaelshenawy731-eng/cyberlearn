
import React from 'react';
import { UserProgress } from '../types';
import { LESSONS } from '../constants';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend, PieChart, Pie, Cell } from 'recharts';
import { Award, BookOpen, Target, Zap, ShieldCheck, Lock, Shield } from 'lucide-react';

interface DashboardProps {
  progress: UserProgress;
}

const COLORS = ['#06b6d4', '#334155']; // Accent vs Slate

const Dashboard: React.FC<DashboardProps> = ({ progress }) => {
  // 1. Process Lesson Stats
  const lessonValues = Object.values(progress.lessons) as {
    preQuizScore?: number;
    postQuizScore?: number;
    completed: boolean;
  }[];

  const completedLessonsCount = lessonValues.filter(p => p.completed).length;
  const totalScore = lessonValues.reduce((acc, curr) => acc + (curr.postQuizScore || 0), 0);
  const maxPossibleScore = LESSONS.length * 10; // 10 questions each now

  // 2. Process Activity Stats
  const activities = progress.activities;
  const completedActivitiesCount = Object.values(activities).filter(Boolean).length;
  const totalActivities = 4; // Phishing, Network, Crypto, Access

  // 3. Prepare Chart Data (Ensure numeric values)
  const barData = LESSONS.map(lesson => {
    const p = progress.lessons[lesson.id];
    return {
      name: lesson.title.split(' ')[0], // Short name
      pre: p?.preQuizScore !== undefined ? p.preQuizScore : 0,
      post: p?.postQuizScore !== undefined ? p.postQuizScore : 0,
    };
  });

  const pieData = [
      { name: 'مكتمل', value: completedLessonsCount },
      { name: 'متبقي', value: LESSONS.length - completedLessonsCount }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <h2 className="text-3xl font-bold text-white mb-8 border-r-4 border-cyber-accent pr-4">لوحة التحكم والأداء</h2>

      {/* Top Stats Row */}
      <div className="grid md:grid-cols-4 gap-6 mb-12">
        <div className="bg-cyber-800 p-6 rounded-2xl border border-cyber-700 flex flex-col justify-between h-32">
          <div className="flex justify-between items-start">
              <p className="text-slate-400 text-sm font-bold">الدروس المكتملة</p>
              <BookOpen className="text-cyber-accent" size={24} />
          </div>
          <p className="text-4xl font-bold text-white">{completedLessonsCount} <span className="text-lg text-slate-500">/ {LESSONS.length}</span></p>
        </div>

        <div className="bg-cyber-800 p-6 rounded-2xl border border-cyber-700 flex flex-col justify-between h-32">
          <div className="flex justify-between items-start">
              <p className="text-slate-400 text-sm font-bold">الأنشطة المنجزة</p>
              <Zap className="text-purple-500" size={24} />
          </div>
          <p className="text-4xl font-bold text-white">{completedActivitiesCount} <span className="text-lg text-slate-500">/ {totalActivities}</span></p>
        </div>

        <div className="bg-cyber-800 p-6 rounded-2xl border border-cyber-700 flex flex-col justify-between h-32">
          <div className="flex justify-between items-start">
              <p className="text-slate-400 text-sm font-bold">مجموع النقاط</p>
              <Target className="text-emerald-500" size={24} />
          </div>
          <p className="text-4xl font-bold text-white">{totalScore}</p>
        </div>

        <div className="bg-cyber-800 p-6 rounded-2xl border border-cyber-700 flex flex-col justify-between h-32">
           <div className="flex justify-between items-start">
              <p className="text-slate-400 text-sm font-bold">اللقب الحالي</p>
              <Award className="text-yellow-500" size={24} />
          </div>
          <p className="text-xl font-bold text-white truncate">
              {completedLessonsCount === 0 ? 'مبتدئ' : completedLessonsCount < 4 ? 'متدرب أمني' : 'خبير سايبر'}
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8 mb-8">
          {/* Main Bar Chart */}
          <div className="lg:col-span-2 bg-cyber-800 p-6 rounded-2xl border border-cyber-700 h-[400px]">
            <h3 className="text-xl font-bold text-white mb-6">تحليل الأداء (القبلي vs البعدي)</h3>
            <ResponsiveContainer width="100%" height="85%">
            <BarChart
                data={barData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" tick={{fill: '#94a3b8'}} />
                <YAxis stroke="#94a3b8" tick={{fill: '#94a3b8'}} domain={[0, 10]} />
                <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f1f5f9', borderRadius: '8px' }}
                cursor={{fill: '#334155', opacity: 0.3}}
                />
                <Legend />
                <Bar dataKey="pre" fill="#64748b" name="اختبار قبلي" radius={[4, 4, 0, 0]} barSize={20} />
                <Bar dataKey="post" fill="#06b6d4" name="اختبار بعدي" radius={[4, 4, 0, 0]} barSize={20} />
            </BarChart>
            </ResponsiveContainer>
        </div>

        {/* Pie Chart & Activity Checklist */}
        <div className="flex flex-col gap-6">
             <div className="bg-cyber-800 p-6 rounded-2xl border border-cyber-700 flex-1 min-h-[200px] flex flex-col items-center justify-center relative">
                 <h3 className="absolute top-4 right-4 text-sm font-bold text-slate-400">نسبة الإنجاز</h3>
                 <ResponsiveContainer width="100%" height={180}>
                    <PieChart>
                        <Pie
                            data={pieData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            fill="#8884d8"
                            paddingAngle={5}
                            dataKey="value"
                            stroke="none"
                        >
                            {pieData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                    </PieChart>
                 </ResponsiveContainer>
                 <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                     <span className="text-3xl font-bold text-white">
                         {Math.round((completedLessonsCount / LESSONS.length) * 100)}%
                     </span>
                 </div>
             </div>

             <div className="bg-cyber-800 p-6 rounded-2xl border border-cyber-700 flex-1">
                 <h3 className="text-white font-bold mb-4">قائمة الأنشطة</h3>
                 <div className="space-y-3">
                     <ActivityItem label="محاكي التصيد" done={activities.phishing} icon={<ShieldCheck size={16}/>} />
                     <ActivityItem label="محلل الشبكة" done={activities.network} icon={<Zap size={16}/>} />
                     <ActivityItem label="مختبر التشفير" done={activities.crypto} icon={<Lock size={16}/>} />
                     <ActivityItem label="مصفوفة الصلاحيات" done={activities.access} icon={<Shield size={16}/>} />
                 </div>
             </div>
        </div>
      </div>
    </div>
  );
};

const ActivityItem = ({label, done, icon}: {label: string, done: boolean, icon: React.ReactNode}) => (
    <div className={`flex items-center justify-between p-3 rounded-lg border ${done ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-cyber-900 border-cyber-700'}`}>
        <div className="flex items-center gap-2 text-sm text-slate-300">
            {icon}
            {label}
        </div>
        <div className={`w-3 h-3 rounded-full ${done ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-cyber-700'}`}></div>
    </div>
)

export default Dashboard;
