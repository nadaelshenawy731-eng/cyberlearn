
import React, { useState, useEffect } from 'react';
import { Lesson, UserProgress, Question } from '../types';
import Quiz from './Quiz';
import { BookOpen, CheckCircle, ArrowLeft, HelpCircle, AlertTriangle, RotateCcw, XCircle } from 'lucide-react';

interface LessonViewProps {
  lesson: Lesson;
  progress: UserProgress['lessons']; // Use updated type
  onUpdateProgress: (lessonId: string, data: Partial<UserProgress['lessons'][string]>) => void;
  onExit: () => void;
}

type Step = 'PRE_QUIZ' | 'CONTENT' | 'POST_QUIZ' | 'SUMMARY' | 'FAILED';

// Mini Component for Inline Questions
const InlineCheckup: React.FC<{ question: Question }> = ({ question }) => {
  const [selected, setSelected] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  const handleSelect = (idx: number) => {
    setSelected(idx);
    setIsCorrect(idx === question.correctAnswer);
  };

  return (
    <div className="mt-6 bg-cyber-900/50 p-6 rounded-xl border border-cyber-700/50">
      <div className="flex items-center gap-2 mb-4 text-cyber-accent font-bold">
        <HelpCircle size={20} />
        <span>اختبر نفسك</span>
      </div>
      <p className="text-white mb-4 font-bold">{question.text}</p>
      <div className="space-y-2">
        {question.options.map((opt, i) => (
          <button
            key={i}
            onClick={() => handleSelect(i)}
            disabled={selected !== null}
            className={`w-full text-right p-3 rounded-lg border transition-all ${
              selected === i 
                ? i === question.correctAnswer 
                    ? 'bg-emerald-500/20 border-emerald-500 text-white' 
                    : 'bg-red-500/20 border-red-500 text-white'
                : 'bg-cyber-800 border-cyber-700 hover:bg-cyber-700 text-slate-300'
            }`}
          >
            {opt}
            {selected === i && (
                <span className="float-left">
                    {i === question.correctAnswer ? '✅' : '❌'}
                </span>
            )}
          </button>
        ))}
      </div>
      {selected !== null && (
          <div className={`mt-4 text-sm p-3 rounded ${isCorrect ? 'text-emerald-400 bg-emerald-900/20' : 'text-red-400 bg-red-900/20'}`}>
              <strong>توضيح: </strong> {question.feedback}
          </div>
      )}
    </div>
  );
};

const LessonView: React.FC<LessonViewProps> = ({ lesson, progress, onUpdateProgress, onExit }) => {
  const [step, setStep] = useState<Step>('PRE_QUIZ');
  // Local state to hold scores temporarily for immediate display before parent updates
  const [localPreScore, setLocalPreScore] = useState<number | undefined>(undefined);
  const [localPostScore, setLocalPostScore] = useState<number | undefined>(undefined);
  const [quizAttempt, setQuizAttempt] = useState(0); // Key to reset quiz component

  const userLessonData = progress[lesson.id] || { completed: false };

  // Determine initial step based on progress
  useEffect(() => {
    if (userLessonData.completed) {
      setStep('SUMMARY');
    } else if (userLessonData.postQuizScore !== undefined && userLessonData.completed) {
      setStep('SUMMARY');
    } else if (userLessonData.preQuizScore !== undefined) {
      setStep('CONTENT');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Run once on mount

  const handlePreQuizComplete = (score: number) => {
    setLocalPreScore(score);
    onUpdateProgress(lesson.id, { preQuizScore: score });
    setStep('CONTENT');
  };

  const handlePostQuizComplete = (score: number) => {
    setLocalPostScore(score);
    const passingScore = Math.ceil(lesson.postQuiz.length * 0.7); // 70% passing grade
    
    if (score >= passingScore) {
      onUpdateProgress(lesson.id, { postQuizScore: score, completed: true });
      setTimeout(() => setStep('SUMMARY'), 1500); // Small delay to see result
    } else {
      // Failed
      setTimeout(() => setStep('FAILED'), 1500);
    }
  };

  const handleContentComplete = () => {
    setStep('POST_QUIZ');
  };

  const retryQuiz = () => {
      setQuizAttempt(prev => prev + 1);
      setStep('POST_QUIZ');
  }

  const reviewLesson = () => {
      setStep('CONTENT');
  }

  // Safe access to scores (prefer local state if available immediately after quiz, else prop)
  const displayPreScore = localPreScore !== undefined ? localPreScore : userLessonData.preQuizScore;
  const displayPostScore = localPostScore !== undefined ? localPostScore : userLessonData.postQuizScore;

  if (step === 'PRE_QUIZ') {
    return (
      <div className="container mx-auto px-4 py-8 animate-fade-in">
        <div className="mb-6">
            <button onClick={onExit} className="text-slate-400 hover:text-white flex items-center gap-2 mb-4">
                <ArrowLeft size={16} /> العودة للدروس
            </button>
            <h1 className="text-3xl font-bold text-white mb-2">{lesson.title}</h1>
            <p className="text-slate-400">المرحلة 1: قياس المعرفة القبلية</p>
        </div>
        <Quiz questions={lesson.preQuiz} onComplete={handlePreQuizComplete} type="PRE" />
      </div>
    );
  }

  if (step === 'CONTENT') {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl animate-fade-in">
        <div className="flex justify-between items-center mb-8 border-b border-cyber-700 pb-4">
           <div>
               <h1 className="text-3xl font-bold text-white mb-2">{lesson.content.title}</h1>
               <p className="text-cyber-accent">المادة التعليمية</p>
           </div>
           <BookOpen className="text-cyber-700 w-12 h-12" />
        </div>

        <div className="space-y-8 mb-12">
          {lesson.content.sections.map((section, idx) => (
            <div key={idx} className="bg-cyber-800 p-6 rounded-2xl border border-cyber-700 shadow-lg">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-3">
                <span className="bg-cyber-accent/20 text-cyber-accent w-8 h-8 rounded-full flex items-center justify-center text-sm">{idx + 1}</span>
                {section.heading}
              </h2>
              <p className="text-slate-300 leading-8 text-lg">{section.content}</p>
              
              {/* Render Inline Checkup Question if exists */}
              {section.checkupQuestion && (
                  <InlineCheckup question={section.checkupQuestion} />
              )}
            </div>
          ))}
        </div>

        <div className="flex justify-center">
          <button 
            onClick={handleContentComplete}
            className="bg-cyber-accent text-cyber-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-cyan-300 transition shadow-lg shadow-cyber-accent/20 flex items-center gap-2"
          >
            استيعاب المحتوى والانتقال للاختبار البعدي
            <ArrowLeft />
          </button>
        </div>
      </div>
    );
  }

  if (step === 'POST_QUIZ') {
    return (
      <div className="container mx-auto px-4 py-8 animate-fade-in">
        <div className="mb-6 text-center">
            <h1 className="text-3xl font-bold text-white mb-2">{lesson.title}</h1>
            <p className="text-slate-400">المرحلة النهائية: الاختبار البعدي (10 أسئلة)</p>
            <p className="text-xs text-slate-500 mt-2">درجة النجاح المطلوبة: 70%</p>
        </div>
        <Quiz key={quizAttempt} questions={lesson.postQuiz} onComplete={handlePostQuizComplete} type="POST" />
      </div>
    );
  }

  if (step === 'FAILED') {
      return (
        <div className="container mx-auto px-4 py-12 text-center animate-fade-in">
            <div className="max-w-xl mx-auto bg-cyber-800 p-8 rounded-3xl border border-red-500/30 shadow-2xl shadow-red-500/10">
                <XCircle className="w-24 h-24 text-red-500 mx-auto mb-6" />
                <h2 className="text-3xl font-bold text-white mb-4">للأسف، لم تنجح</h2>
                <p className="text-slate-300 text-lg mb-2">
                  لقد حصلت على <span className="text-red-400 font-bold">{localPostScore}</span> من <span className="text-white">{lesson.postQuiz.length}</span>.
                </p>
                <p className="text-slate-400 text-sm mb-8">يجب عليك الحصول على 70% على الأقل لاجتياز الدرس.</p>

                <div className="flex flex-col gap-4">
                    <button 
                        onClick={retryQuiz}
                        className="bg-cyber-accent text-cyber-900 px-8 py-3 rounded-xl font-bold hover:bg-cyan-300 transition w-full flex items-center justify-center gap-2"
                    >
                        <RotateCcw size={18} /> إعادة الاختبار
                    </button>
                    <button 
                        onClick={reviewLesson}
                        className="bg-cyber-900 text-slate-300 border border-cyber-700 px-8 py-3 rounded-xl font-bold hover:text-white transition w-full flex items-center justify-center gap-2"
                    >
                        <BookOpen size={18} /> مراجعة الدرس
                    </button>
                </div>
            </div>
        </div>
      )
  }

  // Summary Step
  return (
    <div className="container mx-auto px-4 py-12 text-center animate-fade-in">
      <div className="max-w-xl mx-auto bg-cyber-800 p-8 rounded-3xl border border-emerald-500/30 shadow-2xl shadow-emerald-500/10">
        <CheckCircle className="w-24 h-24 text-emerald-500 mx-auto mb-6" />
        <h2 className="text-3xl font-bold text-white mb-4">تهانينا!</h2>
        <p className="text-slate-300 text-lg mb-8">
          أتممت درس <span className="text-cyber-accent font-bold">"{lesson.title}"</span> بنجاح.
        </p>
        
        <div className="grid grid-cols-2 gap-4 mb-8">
           <div className="bg-cyber-900 p-4 rounded-xl">
               <span className="block text-slate-500 text-sm">درجة القبلي</span>
               <span className="text-2xl font-bold text-white">
                   {displayPreScore !== undefined ? displayPreScore : '-'} / {lesson.preQuiz.length}
               </span>
           </div>
           <div className="bg-cyber-900 p-4 rounded-xl border border-emerald-500/30">
               <span className="block text-slate-500 text-sm">درجة البعدي</span>
               <span className="text-2xl font-bold text-emerald-400">
                   {displayPostScore !== undefined ? displayPostScore : '-'} / {lesson.postQuiz.length}
               </span>
           </div>
        </div>

        <button 
          onClick={onExit}
          className="bg-cyber-accent text-cyber-900 px-8 py-3 rounded-xl font-bold hover:bg-cyan-300 transition w-full"
        >
          العودة للقائمة الرئيسية
        </button>
      </div>
    </div>
  );
};

export default LessonView;
