
import React, { useState } from 'react';
import { Shield, Users, FileText, Check, X, AlertOctagon } from 'lucide-react';

// Users and Resources
const ROLES = ['Admin', 'Manager', 'Employee', 'Guest'];
const RESOURCES = ['System Settings', 'Financial Reports', 'Project Files', 'Public Website'];

// The correct permission matrix (Least Privilege)
// true = Access Allowed, false = Access Denied
const CORRECT_MATRIX = {
    'Admin': [true, true, true, true],
    'Manager': [false, true, true, true],
    'Employee': [false, false, true, true],
    'Guest': [false, false, false, true]
};

interface AccessControlProps {
    onComplete?: () => void;
}

const AccessControl: React.FC<AccessControlProps> = ({ onComplete }) => {
  // State: 4x4 boolean matrix
  const [permissions, setPermissions] = useState<boolean[][]>(
      Array(4).fill(null).map(() => Array(4).fill(false))
  );
  const [result, setResult] = useState<'SUCCESS' | 'FAILURE' | null>(null);

  const togglePermission = (rIdx: number, cIdx: number) => {
      const newPerms = [...permissions];
      newPerms[rIdx] = [...newPerms[rIdx]];
      newPerms[rIdx][cIdx] = !newPerms[rIdx][cIdx];
      setPermissions(newPerms);
      setResult(null);
  };

  const validate = () => {
      let isCorrect = true;
      ROLES.forEach((role, rIdx) => {
          const expectedRow = CORRECT_MATRIX[role as keyof typeof CORRECT_MATRIX];
          expectedRow.forEach((val, cIdx) => {
              if (permissions[rIdx][cIdx] !== val) isCorrect = false;
          });
      });

      if (isCorrect) {
          setResult('SUCCESS');
          if (onComplete) onComplete();
      } else {
          setResult('FAILURE');
      }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-white mb-2 flex items-center justify-center gap-2">
            <Shield className="text-purple-500" /> مصفوفة الصلاحيات (ACL)
        </h2>
        <p className="text-slate-400 max-w-2xl mx-auto">
            مهمتك هي تطبيق مبدأ "أقل الامتيازات" (Least Privilege).
            <br/>
            امنح الصلاحيات المناسبة لكل دور وظيفي دون زيادة تعرض النظام للخطر.
        </p>
      </div>

      <div className="bg-cyber-800 rounded-2xl p-8 border border-cyber-700 shadow-2xl overflow-x-auto">
          <table className="w-full text-right border-collapse">
              <thead>
                  <tr>
                      <th className="p-4 text-slate-500 border-b border-cyber-700">الدور / الموارد</th>
                      {RESOURCES.map((res, i) => (
                          <th key={i} className="p-4 text-white border-b border-cyber-700 text-center min-w-[120px]">
                              <div className="flex flex-col items-center gap-2">
                                  <FileText size={20} className="text-cyber-accent" />
                                  <span className="text-sm">{res}</span>
                              </div>
                          </th>
                      ))}
                  </tr>
              </thead>
              <tbody>
                  {ROLES.map((role, rIdx) => (
                      <tr key={rIdx} className="hover:bg-cyber-700/50 transition">
                          <td className="p-4 border-b border-cyber-700 font-bold text-white flex items-center gap-2">
                              <Users size={18} className="text-slate-400" />
                              {role}
                          </td>
                          {permissions[rIdx].map((allowed, cIdx) => (
                              <td key={cIdx} className="p-4 border-b border-cyber-700 text-center">
                                  <button
                                    onClick={() => togglePermission(rIdx, cIdx)}
                                    className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all duration-200 ${
                                        allowed 
                                        ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30' 
                                        : 'bg-cyber-900 text-slate-600 border border-cyber-600 hover:border-cyber-400'
                                    }`}
                                  >
                                      {allowed ? <Check size={20} /> : <X size={20} />}
                                  </button>
                              </td>
                          ))}
                      </tr>
                  ))}
              </tbody>
          </table>
      </div>

      <div className="mt-8 flex flex-col items-center gap-4">
          <button 
            onClick={validate}
            className="px-10 py-4 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl shadow-lg transition text-lg"
          >
              تحقق من الصلاحيات
          </button>

          {result === 'SUCCESS' && (
              <div className="p-4 bg-emerald-500/20 border border-emerald-500 text-emerald-400 rounded-xl flex items-center gap-3 animate-fade-in">
                  <Check className="w-6 h-6" />
                  <div>
                      <strong>ممتاز!</strong> تم تطبيق سياسة الأمان بشكل صحيح.
                  </div>
              </div>
          )}

          {result === 'FAILURE' && (
              <div className="p-4 bg-red-500/20 border border-red-500 text-red-400 rounded-xl flex items-center gap-3 animate-fade-in">
                  <AlertOctagon className="w-6 h-6" />
                  <div>
                      <strong>خطأ أمني!</strong> إما منحت صلاحيات زائدة لغير المستحقين، أو منعت الوصول عن المصرح لهم.
                  </div>
              </div>
          )}
      </div>
    </div>
  );
};

export default AccessControl;
