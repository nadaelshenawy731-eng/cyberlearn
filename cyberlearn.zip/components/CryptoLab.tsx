
import React, { useState } from 'react';
import { Lock, Unlock, Hash, Key, RefreshCw, CheckCircle, XCircle, ArrowLeft } from 'lucide-react';

interface Challenge {
  id: number;
  title: string;
  type: 'DECRYPT' | 'HASH';
  description: string;
  cipherText: string;
  hint: string;
  answer: string;
  shift?: number; // For Caesar
}

const CHALLENGES: Challenge[] = [
  {
    id: 1,
    title: "مستوى 1: تشفير القيصر",
    type: 'DECRYPT',
    description: "تم اعتراض رسالة مشفرة باستخدام تشفير القيصر (Caesar Cipher) بإزاحة مقدارها 3. قم بفك التشفير.",
    cipherText: "KHOOR ZRUOG", // HELLO WORLD
    answer: "HELLO WORLD",
    hint: "ارجع كل حرف 3 خطوات للوراء في الأبجدية الإنجليزية (K -> H)",
    shift: 3
  },
  {
    id: 2,
    title: "مستوى 2: التشفير المعكوس",
    type: 'DECRYPT',
    description: "رسالة سرية تم عكس حروفها. اقرأها وأدخل النص الأصلي.",
    cipherText: "!ytiruceS rebyC",
    answer: "Cyber Security!",
    hint: "اقرأ من اليمين لليسار.",
  },
  {
    id: 3,
    title: "مستوى 3: Hashing (متقدم)",
    type: 'HASH',
    description: "أي من النصوص التالية ينتج عنه الهاش (MD5) التالي: '5d41402abc4b2a76b9719d911017c592'؟",
    cipherText: "Hash: 5d41402abc4b2a76b9719d911017c592",
    answer: "hello",
    hint: "هذا الهاش مشهور جداً لكلمة ترحيب بالإنجليزية.",
  }
];

interface CryptoLabProps {
    onComplete?: () => void;
}

const CryptoLab: React.FC<CryptoLabProps> = ({ onComplete }) => {
  const [currentLevel, setCurrentLevel] = useState(0);
  const [userInput, setUserInput] = useState('');
  const [feedback, setFeedback] = useState<'CORRECT' | 'WRONG' | null>(null);
  const [completed, setCompleted] = useState(false);

  const currentChallenge = CHALLENGES[currentLevel];

  const handleSubmit = () => {
    if (userInput.toLowerCase().trim() === currentChallenge.answer.toLowerCase()) {
      setFeedback('CORRECT');
      if (currentLevel === CHALLENGES.length - 1) {
        setCompleted(true);
        if (onComplete) onComplete();
      }
    } else {
      setFeedback('WRONG');
    }
  };

  const nextLevel = () => {
    setFeedback(null);
    setUserInput('');
    setCurrentLevel(l => l + 1);
  };

  if (completed) {
      return (
          <div className="max-w-2xl mx-auto px-4 py-12 text-center animate-fade-in">
              <div className="bg-cyber-800 p-8 rounded-2xl border border-emerald-500 shadow-xl">
                  <Unlock size={64} className="mx-auto text-emerald-500 mb-6" />
                  <h2 className="text-3xl font-bold text-white mb-4">تم كسر الشفرة!</h2>
                  <p className="text-slate-300 mb-6">لقد أثبت مهارتك في تحليل التشفير الأساسي.</p>
                  <div className="bg-black/50 p-4 rounded-lg font-mono text-emerald-400 mb-6">
                      ACCESS GRANTED_
                  </div>
              </div>
          </div>
      )
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2 flex items-center justify-center gap-2">
            <Lock className="text-cyber-accent"/> مختبر التشفير
        </h2>
        <p className="text-slate-400">استخدم أدوات التحليل لفك الشفرات وتجاوز الحماية.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
          {/* Challenge Card */}
          <div className="bg-cyber-800 border-2 border-cyber-700 rounded-2xl p-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-2 bg-cyber-700 rounded-bl-xl text-xs font-bold text-cyber-accent">
                  LEVEL {currentLevel + 1}/{CHALLENGES.length}
              </div>
              
              <h3 className="text-xl font-bold text-white mb-4 mt-2">{currentChallenge.title}</h3>
              <p className="text-slate-300 mb-6">{currentChallenge.description}</p>
              
              <div className="bg-black p-4 rounded-lg border border-slate-700 mb-6 relative group">
                  <span className="text-xs text-slate-500 absolute top-2 right-2">CIPHERTEXT</span>
                  <p className="font-mono text-2xl text-red-500 tracking-widest text-center break-all">{currentChallenge.cipherText}</p>
              </div>

              <div className="flex items-center gap-2 text-sm text-yellow-500 bg-yellow-500/10 p-3 rounded mb-6">
                  <Key size={16} />
                  <span>تلميح: {currentChallenge.hint}</span>
              </div>
          </div>

          {/* Interaction Panel */}
          <div className="bg-cyber-900 border border-cyber-700 rounded-2xl p-6 flex flex-col justify-center">
             <div className="mb-6">
                 <label className="block text-slate-400 mb-2 font-bold">أدخل النص المفكوك (Decrypted Text):</label>
                 <input 
                    type="text" 
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    placeholder="Type answer here..."
                    className="w-full bg-black border border-cyber-600 rounded-lg p-4 text-white font-mono focus:border-cyber-accent focus:outline-none text-lg"
                 />
             </div>

             {feedback === 'WRONG' && (
                 <div className="mb-4 text-red-500 flex items-center gap-2 bg-red-500/10 p-3 rounded">
                     <XCircle size={20} />
                     <span>إجابة خاطئة، حاول مجدداً.</span>
                 </div>
             )}

             {feedback === 'CORRECT' ? (
                 <div className="text-center animate-fade-in">
                     <div className="mb-4 text-emerald-500 flex items-center justify-center gap-2 bg-emerald-500/10 p-3 rounded font-bold">
                        <CheckCircle size={24} />
                        <span>إجابة صحيحة!</span>
                    </div>
                    <button 
                        onClick={nextLevel}
                        className="w-full bg-cyber-accent text-cyber-900 font-bold py-3 rounded-lg hover:bg-cyan-300 transition flex items-center justify-center gap-2"
                    >
                        المستوى التالي <ArrowLeft />
                    </button>
                 </div>
             ) : (
                <button 
                    onClick={handleSubmit}
                    className="w-full bg-slate-700 text-white font-bold py-3 rounded-lg hover:bg-slate-600 transition flex items-center justify-center gap-2"
                >
                    <Unlock size={18} />
                    فك التشفير
                </button>
             )}
          </div>
      </div>
    </div>
  );
};

export default CryptoLab;
