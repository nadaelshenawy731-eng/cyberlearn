import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-cyber-900 border-t border-cyber-700 py-8 mt-12">
      <div className="container mx-auto px-4 text-center">
        <p className="text-slate-400">© 2025 CyberLearn. جميع الحقوق محفوظة.</p>
        <p className="text-slate-600 text-sm mt-2">تعلم لنحمي مستقبلنا الرقمي</p>
      </div>
    </footer>
  );
};

export default Footer;