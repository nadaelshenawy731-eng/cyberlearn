
import React, { useState, useEffect } from 'react';
import { Question } from '../types';
import { CheckCircle, XCircle, ArrowLeft } from 'lucide-react';

interface QuizProps {
  questions: Question[];
  onComplete: (score: number) => void;
  type: 'PRE' | 'POST';
}

const Quiz: React.FC<QuizProps> = ({ questions, onComplete, type }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [answers, setAnswers] = useState<{qId: number, correct: boolean, userAns: number}[]>([]);

  // Effect to scroll to top when question changes
  useEffect(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentIndex, isFinished]);

  const handleOptionClick = (index: number) => {
    if (showFeedback) return;
    setSelectedOption(index);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null) return;

    const currentQ = questions[currentIndex];
    const isCorrect = selectedOption === currentQ.correctAnswer;
    
    if (isCorrect) setScore(s => s + 1);
    
    setAnswers([...answers, {
      qId: currentQ.id,
      correct: isCorrect,
      userAns: selectedOption
    }]);

    setShowFeedback(true);
  };

  const handleNext = () => {
    setShowFeedback(false);
    setSelectedOption(null);
    
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      setIsFinished(true);
      // Calculate final score directly from answers array to avoid any state update race conditions
      // This ensures the score passed to onComplete is 100% accurate based on the user's history
      const finalScore = answers.filter(a => a.correct).length;
      onComplete(finalScore);
    }
  };

  if (isFinished) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="bg-cyber-800 p-8 rounded-2xl border border-cyber-700 text-center animate-fade-in">
        <h2 className="text-2xl font-bold mb-4 text-white">
          {type === 'PRE' ? 'نتيجة الاختبار القبلي' : 'نتيجة الاختبار البعدي'}
        </h2>
        
        <div className={`w-32 h-32 mx-auto rounded-full flex items-center justify-center border-4 mb-6 ${percentage >= 70 ? 'border-emerald-500' : 'border-cyber-accent'}`}>
          <span className={`text-3xl font-bold ${percentage >= 70 ? 'text-emerald-500' : 'text-cyber-accent'}`}>{percentage}%</span>
        </div>

        <p className="text-slate-300 mb-6">
          أجبت بشكل صحيح على <span className="text-white font-bold">{score}</span> من <span className="text-white font-bold">{questions.length}</span> أسئلة.
        </p>

        <div className="space-y-4 text-right mb-8">
          {questions.map((q, idx) => {
            const ans = answers.find(a => a.qId === q.id);
            if (!ans) return null;
            return (
              <div key={q.id} className={`p-4 rounded-lg border ${ans.correct ? 'border-cyber-success/30 bg-cyber-success/10' : 'border-cyber-danger/30 bg-cyber-danger/10'}`}>
                <p className="font-semibold text-white mb-2">{idx + 1}. {q.text}</p>
                <p className="text-sm text-slate-300 flex items-center gap-2">
                  {ans.correct ? <CheckCircle className="text-cyber-success w-4 h-4"/> : <XCircle className="text-cyber-danger w-4 h-4"/>}
                  {ans.correct ? 'إجابة صحيحة' : `إجابة خاطئة. الصحيح: ${q.options[q.correctAnswer]}`}
                </p>
                {!ans.correct && (
                    <p className="text-xs text-slate-400 mt-2 bg-black/20 p-2 rounded">💡 {q.feedback}</p>
                )}
              </div>
            )
          })}
        </div>
      </div>
    );
  }

  const currentQ = questions[currentIndex];

  return (
    <div className="max-w-2xl mx-auto bg-cyber-800 rounded-2xl shadow-xl border border-cyber-700 overflow-hidden">
      {/* Progress Bar */}
      <div className="bg-cyber-900 h-2 w-full">
        <div 
          className="bg-cyber-accent h-full transition-all duration-300" 
          style={{ width: `${((currentIndex) / questions.length) * 100}%` }}
        ></div>
      </div>

      <div className="p-6 md:p-8">
        <div className="flex justify-between items-center mb-6">
            <span className="text-cyber-accent text-sm font-bold tracking-wider">
                {type === 'PRE' ? 'اختبار قبلي' : 'اختبار بعدي'}
            </span>
            <span className="text-slate-400 text-sm">
                سؤال {currentIndex + 1} من {questions.length}
            </span>
        </div>

        <h3 className="text-xl font-bold text-white mb-6 leading-relaxed">
          {currentQ.text}
        </h3>

        <div className="space-y-3">
          {currentQ.options.map((option, idx) => {
            let btnClass = "w-full p-4 rounded-xl text-right transition-all border-2 ";
            
            if (showFeedback) {
              if (idx === currentQ.correctAnswer) {
                btnClass += "border-cyber-success bg-cyber-success/20 text-white";
              } else if (idx === selectedOption) {
                btnClass += "border-cyber-danger bg-cyber-danger/20 text-white";
              } else {
                btnClass += "border-cyber-700 bg-cyber-900/50 text-slate-500 opacity-50";
              }
            } else {
              if (selectedOption === idx) {
                btnClass += "border-cyber-accent bg-cyber-accent/10 text-white";
              } else {
                btnClass += "border-cyber-700 bg-cyber-900 hover:border-cyber-accent/50 text-slate-200";
              }
            }

            return (
              <button
                key={idx}
                onClick={() => handleOptionClick(idx)}
                className={btnClass}
                disabled={showFeedback}
              >
                <div className="flex justify-between items-center">
                    <span>{option}</span>
                    {showFeedback && idx === currentQ.correctAnswer && <CheckCircle className="text-cyber-success w-5 h-5" />}
                    {showFeedback && idx === selectedOption && idx !== currentQ.correctAnswer && <XCircle className="text-cyber-danger w-5 h-5" />}
                </div>
              </button>
            );
          })}
        </div>

        {showFeedback && (
          <div className="mt-6 p-4 bg-cyber-900/50 rounded-lg border-r-4 border-cyber-accent animate-in fade-in slide-in-from-top-2">
            <p className="text-sm text-slate-300 leading-relaxed">
              <span className="text-cyber-accent font-bold ml-2">توضيح:</span>
              {currentQ.feedback}
            </p>
          </div>
        )}

        <div className="mt-8 flex justify-end">
          {!showFeedback ? (
            <button
              onClick={handleSubmitAnswer}
              disabled={selectedOption === null}
              className={`px-6 py-2 rounded-lg font-bold transition ${selectedOption !== null ? 'bg-cyber-accent text-cyber-900 hover:bg-cyan-300' : 'bg-slate-700 text-slate-500 cursor-not-allowed'}`}
            >
              تأكيد الإجابة
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="px-6 py-2 rounded-lg font-bold bg-cyber-accent text-cyber-900 hover:bg-cyan-300 transition flex items-center gap-2"
            >
              {currentIndex < questions.length - 1 ? 'السؤال التالي' : 'عرض النتائج'}
              <ArrowLeft size={18} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Quiz;
