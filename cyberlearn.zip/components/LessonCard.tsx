import React from 'react';
import { Lesson, UserProgress } from '../types';
import { Book, Key, MailWarning, Users, ShieldCheck, CheckCircle, PlayCircle, Lock } from 'lucide-react';

interface LessonCardProps {
  lesson: Lesson;
  progress: UserProgress['lessons'];
  onClick: () => void;
  index: number;
  isLocked: boolean;
}

// Map string names to actual components safely
const iconMap: Record<string, React.ComponentType<any>> = {
  Key,
  MailWarning,
  Users,
  ShieldCheck,
  Book
};

const LessonCard: React.FC<LessonCardProps> = ({ lesson, progress, onClick, index, isLocked }) => {
  // Safe Icon Loading
  const IconComponent = iconMap[lesson.iconName] || Book;
  
  const isCompleted = progress[lesson.id]?.completed;
  const isStarted = progress[lesson.id]?.preQuizScore !== undefined;

  return (
    <div 
      className={`
        relative rounded-2xl p-6 border transition-all duration-300 overflow-hidden
        ${isLocked 
          ? 'bg-cyber-900 border-cyber-800 opacity-70 cursor-not-allowed grayscale' 
          : 'bg-cyber-800 border-cyber-700 hover:border-cyber-accent hover:shadow-2xl hover:shadow-cyber-accent/10 cursor-pointer group'
        }
      `}
      onClick={!isLocked ? onClick : undefined}
    >
      {/* Background decoration */}
      {!isLocked && (
        <div className="absolute -right-10 -top-10 w-32 h-32 bg-cyber-accent/5 rounded-full group-hover:scale-150 transition-transform duration-500"></div>
      )}

      {/* Lock Overlay */}
      {isLocked && (
        <div className="absolute inset-0 bg-cyber-900/60 flex items-center justify-center z-20 backdrop-blur-[1px]">
           <div className="bg-cyber-800 p-4 rounded-full border border-cyber-700 shadow-xl">
             <Lock className="text-slate-500 w-8 h-8" />
           </div>
        </div>
      )}

      <div className="relative z-10">
        <div className="flex justify-between items-start mb-4">
          <div className={`p-3 rounded-lg ${isLocked ? 'bg-slate-800 text-slate-600' : isCompleted ? 'bg-emerald-500/20 text-emerald-500' : 'bg-cyber-accent/20 text-cyber-accent'}`}>
            <IconComponent size={32} />
          </div>
          {isCompleted && <CheckCircle className="text-emerald-500" />}
        </div>

        <h3 className={`text-xl font-bold mb-2 ${isLocked ? 'text-slate-500' : 'text-white'}`}>{lesson.title}</h3>
        <p className="text-slate-400 text-sm mb-6 line-clamp-2">{lesson.description}</p>

        <div className="flex items-center justify-between mt-auto">
          <span className="text-xs text-slate-500 font-mono">الدرس 0{index + 1}</span>
          
          {!isLocked && (
            <button className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition ${isCompleted ? 'bg-emerald-500 text-cyber-900' : 'bg-cyber-700 text-white group-hover:bg-cyber-accent group-hover:text-cyber-900'}`}>
              {isCompleted ? 'مكتمل' : isStarted ? 'متابعة' : 'ابدأ الدرس'}
              {!isCompleted && <PlayCircle size={16} />}
            </button>
          )}
          
          {isLocked && (
             <span className="flex items-center gap-1 text-xs text-slate-500 bg-cyber-900 px-2 py-1 rounded">
               <Lock size={12} /> مقفل
             </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default LessonCard;