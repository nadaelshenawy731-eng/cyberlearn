import React from 'react';
import { Shield, Home, LayoutDashboard, Menu, X } from 'lucide-react';
import { ViewState } from '../types';

interface HeaderProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <header className="bg-cyber-900 border-b border-cyber-700 sticky top-0 z-50 shadow-lg shadow-cyber-900/50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div 
          className="flex items-center gap-2 cursor-pointer group" 
          onClick={() => setView('HOME')}
        >
          <div className="bg-cyber-accent/10 p-2 rounded-lg group-hover:bg-cyber-accent/20 transition">
            <Shield className="w-8 h-8 text-cyber-accent" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white font-sans tracking-wider">CyberLearn</h1>
            <p className="text-xs text-slate-400">Security Academy</p>
          </div>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex gap-6">
          <button 
            onClick={() => setView('HOME')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${currentView === 'HOME' ? 'bg-cyber-800 text-cyber-accent' : 'text-slate-300 hover:text-white hover:bg-cyber-800'}`}
          >
            <Home size={18} />
            <span>الرئيسية</span>
          </button>
          <button 
            onClick={() => setView('DASHBOARD')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${currentView === 'DASHBOARD' ? 'bg-cyber-800 text-cyber-accent' : 'text-slate-300 hover:text-white hover:bg-cyber-800'}`}
          >
            <LayoutDashboard size={18} />
            <span>لوحة التحكم</span>
          </button>
        </nav>

        {/* Mobile Menu Toggle */}
        <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="md:hidden bg-cyber-800 p-4 flex flex-col gap-2 border-t border-cyber-700">
           <button 
            onClick={() => { setView('HOME'); setIsOpen(false); }}
            className={`flex items-center gap-2 px-4 py-3 rounded-lg ${currentView === 'HOME' ? 'bg-cyber-700 text-cyber-accent' : 'text-slate-300'}`}
          >
            <Home size={18} />
            <span>الرئيسية</span>
          </button>
          <button 
            onClick={() => { setView('DASHBOARD'); setIsOpen(false); }}
            className={`flex items-center gap-2 px-4 py-3 rounded-lg ${currentView === 'DASHBOARD' ? 'bg-cyber-700 text-cyber-accent' : 'text-slate-300'}`}
          >
            <LayoutDashboard size={18} />
            <span>لوحة التحكم</span>
          </button>
        </div>
      )}
    </header>
  );
};

export default Header;