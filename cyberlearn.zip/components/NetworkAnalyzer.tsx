
import React, { useState } from 'react';
import { NETWORK_SCENARIOS } from '../constants';
import { Server, ShieldAlert, Monitor, Wifi, CheckCircle, Smartphone, AlertTriangle, Layers, Lock, Globe, HardDrive } from 'lucide-react';
import { NetworkScenario } from '../types';

const NetworkAnalyzer: React.FC = () => {
  const [selectedDifficulty, setSelectedDifficulty] = useState<'Medium' | 'Hard' | 'Extreme'>('Medium');
  const [selectedScenarioId, setSelectedScenarioId] = useState<number | null>(null);
  const [solvedIds, setSolvedIds] = useState<number[]>([]);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Filter scenarios based on difficulty
  const filteredScenarios = NETWORK_SCENARIOS.filter(s => s.difficulty === selectedDifficulty);
  const activeScenario = NETWORK_SCENARIOS.find(s => s.id === selectedScenarioId);

  const handleFix = (optionIndex: number) => {
    if (!activeScenario) return;
    
    if (optionIndex === activeScenario.correctOption) {
      setSolvedIds(prev => [...prev, activeScenario.id]);
      setFeedback("CORRECT");
    } else {
      setFeedback("WRONG");
    }
  };

  const getIcon = (device: string) => {
    if (device.includes('راوتر') || device.includes('Router') || device.includes('وصول')) return <Wifi className="w-8 h-8" />;
    if (device.includes('سيرفر') || device.includes('Server')) return <Server className="w-8 h-8" />;
    if (device.includes('لابتوب') || device.includes('Workstation')) return <Monitor className="w-8 h-8" />;
    if (device.includes('IoT') || device.includes('Smart')) return <Smartphone className="w-8 h-8" />;
    if (device.includes('موقع') || device.includes('Web')) return <Globe className="w-8 h-8" />;
    if (device.includes('صناعي') || device.includes('SCADA')) return <HardDrive className="w-8 h-8" />;
    return <Layers className="w-8 h-8" />;
  };

  const getDifficultyColor = (diff: string) => {
    switch(diff) {
        case 'Medium': return 'text-yellow-400 border-yellow-400/50 bg-yellow-400/10';
        case 'Hard': return 'text-orange-500 border-orange-500/50 bg-orange-500/10';
        case 'Extreme': return 'text-red-500 border-red-500/50 bg-red-500/10';
        default: return 'text-slate-400';
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="text-center mb-10">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">محلل أمان الشبكة المتقدم</h2>
        <p className="text-slate-400">حدد مستوى الصعوبة، اكتشف الثغرات الحرجة، وقم بتأمين البنية التحتية.</p>
      </div>

      {/* Difficulty Tabs */}
      <div className="flex flex-wrap justify-center gap-4 mb-10">
          {(['Medium', 'Hard', 'Extreme'] as const).map((level) => (
              <button
                key={level}
                onClick={() => { setSelectedDifficulty(level); setSelectedScenarioId(null); setFeedback(null); }}
                className={`px-6 py-3 rounded-xl font-bold border-2 transition-all duration-300 w-full md:w-auto ${
                    selectedDifficulty === level 
                    ? getDifficultyColor(level) + ' shadow-lg scale-105' 
                    : 'border-cyber-700 text-slate-500 hover:border-cyber-600 bg-cyber-900'
                }`}
              >
                  {level === 'Medium' ? 'متوسط' : level === 'Hard' ? 'صعب' : 'صعب جداً'}
              </button>
          ))}
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        
        {/* Network Map / Scenario List */}
        <div className="lg:col-span-8 bg-cyber-800 rounded-2xl p-6 md:p-8 border border-cyber-700 relative overflow-hidden min-h-[400px] flex flex-col">
           <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/circuit-board.png')] opacity-5"></div>
           
           <div className="relative z-10">
               <div className="flex items-center gap-2 mb-8 text-slate-400 text-sm">
                   <Monitor size={16} />
                   <span>شبكة المنطقة: {selectedDifficulty === 'Medium' ? 'المنزل (Home)' : selectedDifficulty === 'Hard' ? 'شركة صغيرة (SMB)' : 'مركز بيانات (Enterprise)'}</span>
               </div>

               <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                  {filteredScenarios.map((scenario) => {
                      const isSolved = solvedIds.includes(scenario.id);
                      const isSelected = selectedScenarioId === scenario.id;
                      // Vulnerable if not solved
                      const isVulnerable = !isSolved; 

                      return (
                          <button
                            key={scenario.id}
                            onClick={() => {
                                setSelectedScenarioId(scenario.id);
                                setFeedback(null);
                            }}
                            className={`
                                relative p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center gap-4 h-40 md:h-44 justify-center group
                                ${isSelected ? 'ring-4 ring-cyber-accent/30 bg-cyber-700' : 'bg-cyber-900/50 hover:bg-cyber-700'}
                                ${isSolved ? 'border-emerald-500/50' : 'border-red-500/30'}
                            `}
                          >
                              <div className={`p-3 md:p-4 rounded-full transition-transform group-hover:scale-110 ${isSolved ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                                  {getIcon(scenario.device)}
                              </div>
                              <span className="text-xs md:text-sm font-bold text-white text-center leading-tight">{scenario.device}</span>
                              
                              {isVulnerable && (
                                  <div className="absolute top-2 right-2 animate-pulse text-red-500">
                                      <AlertTriangle size={16} />
                                  </div>
                              )}
                              {isSolved && (
                                  <div className="absolute top-2 right-2 text-emerald-500">
                                      <CheckCircle size={16} />
                                  </div>
                              )}
                          </button>
                      )
                  })}
                  
                  {/* Filler item to indicate safe zone */}
                  <div className="p-4 rounded-xl border-2 border-cyber-700 border-dashed flex flex-col items-center justify-center opacity-30 h-40 md:h-44 hidden md:flex">
                      <Lock className="mb-2" />
                      <span className="text-xs">جدار ناري</span>
                  </div>
               </div>
           </div>
        </div>

        {/* Console / Action Panel */}
        <div className="lg:col-span-4 bg-black rounded-2xl border border-cyber-600 shadow-2xl overflow-hidden flex flex-col font-mono min-h-[400px]">
           <div className="bg-cyber-800 p-3 border-b border-cyber-700 flex items-center gap-2">
               <div className="w-3 h-3 rounded-full bg-red-500"></div>
               <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
               <div className="w-3 h-3 rounded-full bg-green-500"></div>
               <span className="ml-2 text-xs text-cyber-accent">TERMINAL - ROOT ACCESS</span>
           </div>

           <div className="p-6 flex-grow flex flex-col">
               {!selectedScenarioId ? (
                   <div className="flex-grow flex flex-col items-center justify-center text-center text-slate-500 gap-4">
                       <ShieldAlert size={64} className="opacity-20 animate-pulse" />
                       <p>> AWAITING TARGET SELECTION...</p>
                       <p className="text-xs opacity-50">Select a device from the grid to scan vulnerabilities.</p>
                   </div>
               ) : (
                   <div className="animate-in slide-in-from-right-4 fade-in flex flex-col h-full">
                       <div className="mb-6">
                            <h3 className="text-lg font-bold text-cyber-accent mb-1">> TARGET: {activeScenario?.device}</h3>
                            <div className="h-px w-full bg-cyber-700 mb-4"></div>
                            
                            <p className="text-red-400 text-sm mb-2 uppercase">[!] VULNERABILITY DETECTED</p>
                            <p className="text-slate-300 text-sm leading-relaxed mb-4">
                                {activeScenario?.description}
                            </p>
                       </div>

                       {solvedIds.includes(activeScenario!.id) ? (
                           <div className="mt-auto p-4 bg-emerald-900/20 border border-emerald-500 rounded text-center">
                               <p className="text-emerald-500 font-bold mb-1">>> SYSTEM SECURED</p>
                               <p className="text-xs text-emerald-300/70">Patch applied successfully.</p>
                           </div>
                       ) : (
                           <div className="mt-auto">
                               <p className="text-cyber-accent text-xs mb-3">>> SELECT REMEDIATION ACTION:</p>
                               <div className="space-y-3">
                                   {activeScenario?.options?.map((opt, idx) => (
                                       <button
                                         key={idx}
                                         onClick={() => handleFix(idx)}
                                         className="w-full text-right p-3 rounded bg-cyber-900 hover:bg-cyber-800 border border-cyber-700 hover:border-cyber-accent text-xs text-slate-300 transition-colors group"
                                       >
                                           <span className="text-cyber-accent opacity-50 group-hover:opacity-100 ml-2">></span>
                                           {opt}
                                       </button>
                                   ))}
                               </div>
                               
                               {feedback === 'WRONG' && (
                                   <div className="mt-4 p-2 bg-red-900/30 border-r-2 border-red-500 text-red-400 text-xs">
                                       [ERROR] Incorrect patch. Vulnerability persists.
                                   </div>
                               )}
                               
                               {feedback === 'CORRECT' && (
                                    <div className="mt-4 p-2 bg-emerald-900/30 border-r-2 border-emerald-500 text-emerald-400 text-xs">
                                       [SUCCESS] {activeScenario?.solution}
                                   </div>
                               )}
                           </div>
                       )}
                   </div>
               )}
           </div>
        </div>

      </div>
    </div>
  );
};

export default NetworkAnalyzer;
