
import React, { useState } from 'react';
import { PHISHING_EMAILS } from '../constants';
import { Mail, AlertTriangle, ShieldCheck, User, ArrowLeft, ArrowRight } from 'lucide-react';

const PhishingSimulator: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [feedback, setFeedback] = useState<'CORRECT' | 'WRONG' | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);

  const currentEmail = PHISHING_EMAILS[currentIndex];

  const handleGuess = (guessIsPhishing: boolean) => {
    if (showExplanation) return;
    
    const isCorrect = guessIsPhishing === currentEmail.isPhishing;
    if (isCorrect) setScore(s => s + 1);
    
    setFeedback(isCorrect ? 'CORRECT' : 'WRONG');
    setShowExplanation(true);
  };

  const handleNext = () => {
    if (currentIndex < PHISHING_EMAILS.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setFeedback(null);
      setShowExplanation(false);
    }
  };

  const isFinished = currentIndex === PHISHING_EMAILS.length - 1 && showExplanation;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">محاكي كشف التصيد</h2>
        <p className="text-slate-400">حلل رسائل البريد الإلكتروني وحدد ما إذا كانت آمنة أم تصيد احتيالي.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Email Client View */}
        <div className="md:col-span-2 bg-white text-slate-900 rounded-lg overflow-hidden shadow-2xl relative flex flex-col">
            {/* Fake Header */}
            <div className="bg-slate-100 border-b p-3 flex items-center gap-2">
                <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
                <div className="flex-1 text-center text-xs text-slate-500">Inbox - Mail Client</div>
            </div>

            {/* Email Metadata */}
            <div className="p-6 border-b border-slate-100">
                <h3 className="text-xl font-bold mb-4 break-words">{currentEmail.subject}</h3>
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 min-w-[40px] bg-slate-200 rounded-full flex items-center justify-center">
                        <User className="text-slate-500" />
                    </div>
                    <div className="overflow-hidden">
                        <p className="font-bold text-sm">المرسل</p>
                        <p className={`text-sm truncate ${showExplanation && currentEmail.indicators.some(i => currentEmail.sender.includes(i)) ? 'bg-red-100 text-red-700 px-1 rounded' : 'text-slate-600'}`}>
                            {currentEmail.sender}
                        </p>
                    </div>
                </div>
            </div>

            {/* Email Body */}
            <div className="p-6 min-h-[300px] bg-white flex-grow">
                <p className="whitespace-pre-wrap leading-relaxed break-words">
                    {currentEmail.body.split(' ').map((word, i) => {
                        // Very basic highlighter for demo purposes, matches exact substrings from indicators
                        const isSuspicious = showExplanation && currentEmail.indicators.some(ind => word.includes(ind) || currentEmail.body.includes(ind) && word === ind); // Simplification
                        // Better highlight logic:
                        let highlight = false;
                        if (showExplanation) {
                            for(const ind of currentEmail.indicators) {
                                if (word.includes(ind)) highlight = true;
                            }
                        }
                        
                        return (
                            <span key={i} className={highlight ? "bg-red-100 text-red-700 font-bold px-0.5 rounded" : ""}>
                                {word}{' '}
                            </span>
                        )
                    })}
                </p>
                
                <div className="mt-8 pt-6 border-t border-slate-100 text-center">
                    <button className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition">
                         {currentEmail.isPhishing ? "تأكيد / تسجيل الدخول" : "عرض الرسالة"}
                    </button>
                    <p className="text-xs text-slate-400 mt-2">ملاحظة: هذا زر محاكاة، لا تنقر عليه في الحقيقة إذا كنت تشك.</p>
                </div>
            </div>
            
             {/* Overlay for Feedback */}
            {feedback && (
                <div className={`absolute inset-0 bg-black/80 flex flex-col items-center justify-center z-10 animate-fade-in text-center p-4`}>
                    {feedback === 'CORRECT' ? (
                        <CheckCircleIcon size={80} className="text-green-500 mb-4" />
                    ) : (
                        <XCircleIcon size={80} className="text-red-500 mb-4" />
                    )}
                    <h3 className={`text-4xl font-bold ${feedback === 'CORRECT' ? 'text-green-500' : 'text-red-500'}`}>
                        {feedback === 'CORRECT' ? 'أحسنت!' : 'إجابة خاطئة'}
                    </h3>
                </div>
            )}
        </div>

        {/* Controls Side */}
        <div className="flex flex-col gap-4">
            <div className="bg-cyber-800 p-6 rounded-xl border border-cyber-700">
                <div className="flex justify-between items-center mb-4">
                     <span className="text-slate-400">النتيجة: {score}/{PHISHING_EMAILS.length}</span>
                     <span className="text-slate-400">بريد {currentIndex + 1} من {PHISHING_EMAILS.length}</span>
                </div>
                
                {!showExplanation ? (
                    <div className="space-y-4">
                        <p className="text-white text-center mb-4 font-bold">ما هو حكمك على هذه الرسالة؟</p>
                        <button 
                            onClick={() => handleGuess(false)}
                            className="w-full p-4 rounded-lg border-2 border-emerald-500/50 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 flex items-center justify-center gap-2 transition"
                        >
                            <ShieldCheck />
                            <span>آمنة (Safe)</span>
                        </button>
                        <button 
                            onClick={() => handleGuess(true)}
                            className="w-full p-4 rounded-lg border-2 border-red-500/50 bg-red-500/10 hover:bg-red-500/20 text-red-400 flex items-center justify-center gap-2 transition"
                        >
                            <AlertTriangle />
                            <span>تصيد (Phishing)</span>
                        </button>
                    </div>
                ) : (
                    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
                         <div className={`p-4 rounded-lg ${currentEmail.isPhishing ? 'bg-red-500/20 border-red-500/50' : 'bg-green-500/20 border-green-500/50'} border`}>
                            <p className="font-bold text-white mb-2">
                                {currentEmail.isPhishing ? '⚠️ هذه رسالة تصيد!' : '✅ هذه رسالة آمنة.'}
                            </p>
                            <p className="text-sm text-slate-300">{currentEmail.explanation}</p>
                         </div>
                         
                         {!isFinished ? (
                             <button 
                                onClick={handleNext}
                                className="w-full py-3 bg-cyber-accent text-cyber-900 font-bold rounded-lg hover:bg-cyan-300 transition flex items-center justify-center gap-2"
                             >
                                <span>التالي</span>
                                <ArrowLeft size={18} />
                             </button>
                         ) : (
                             <div className="text-center p-4 bg-cyber-700 rounded-lg">
                                 <p className="text-white font-bold mb-2">انتهى التدريب!</p>
                                 <p className="text-cyber-accent">نتيجتك النهائية: {score} من {PHISHING_EMAILS.length}</p>
                             </div>
                         )}
                    </div>
                )}
            </div>
            
            <div className="bg-cyber-900/50 p-4 rounded-lg border border-cyber-700 text-sm text-slate-400">
                <h4 className="font-bold text-white mb-2 flex items-center gap-2">
                    <Mail size={16} /> تلميح سريع
                </h4>
                <p>دائماً تحقق من عنوان البريد الإلكتروني للمرسل بدقة، ولا تنخدع بالشعارات الرسمية.</p>
            </div>
        </div>
      </div>
    </div>
  );
};

// Icons helpers
const CheckCircleIcon = ({size, className}: {size: number, className: string}) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
)
const XCircleIcon = ({size, className}: {size: number, className: string}) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
)

export default PhishingSimulator;
