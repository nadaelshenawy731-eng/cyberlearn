
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import LessonCard from './components/LessonCard';
import LessonView from './components/LessonView';
import Dashboard from './components/Dashboard';
import PhishingSimulator from './components/PhishingSimulator';
import NetworkAnalyzer from './components/NetworkAnalyzer';
import CryptoLab from './components/CryptoLab';
import AccessControl from './components/AccessControl';
import { LESSONS } from './constants';
import { UserProgress, ViewState } from './types';
import { Zap, ShieldCheck, Lock, Shield, LayoutGrid, AlertTriangle } from 'lucide-react';

// Recommended Lessons Mapping
const ACTIVITY_PREREQUISITES: Record<string, string> = {
    'ACTIVITY_PHISHING': 'phishing',
    'ACTIVITY_NETWORK': 'network_security',
    'ACTIVITY_CRYPTO': 'encryption',
    'ACTIVITY_ACCESS': 'access_control'
};

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('HOME');
  const [selectedLessonId, setSelectedLessonId] = useState<string | null>(null);
  
  // Initialize state with default structure to prevent crashes
  const [userProgress, setUserProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('cyberLearnProgressV2'); // Changed key to reset structure if needed
    if (saved) {
        const parsed = JSON.parse(saved);
        // Ensure structure compatibility
        if (!parsed.lessons || !parsed.activities) {
            // Migration or reset
            return { lessons: {}, activities: { phishing: false, network: false, crypto: false, access: false } };
        }
        return parsed;
    }
    return {
        lessons: {},
        activities: {
            phishing: false,
            network: false,
            crypto: false,
            access: false
        }
    };
  });

  useEffect(() => {
    localStorage.setItem('cyberLearnProgressV2', JSON.stringify(userProgress));
  }, [userProgress]);

  const updateLessonProgress = (lessonId: string, data: Partial<UserProgress['lessons'][string]>) => {
    setUserProgress(prev => ({
      ...prev,
      lessons: {
          ...prev.lessons,
          [lessonId]: {
              ...(prev.lessons[lessonId] || { completed: false }),
              ...data
          }
      }
    }));
  };

  const completeActivity = (activityKey: keyof UserProgress['activities']) => {
      setUserProgress(prev => ({
          ...prev,
          activities: {
              ...prev.activities,
              [activityKey]: true
          }
      }));
  };

  const handleLessonSelect = (id: string, isLocked: boolean) => {
    if (isLocked) return;
    setSelectedLessonId(id);
    setCurrentView('LESSON');
  };

  // Calculate global progress
  const completedLessons = Object.values(userProgress.lessons).filter(p => p.completed).length;
  const progressPercentage = (completedLessons / LESSONS.length) * 100;

  // Calculate Activity Progress
  const completedActs = Object.values(userProgress.activities).filter(Boolean).length;
  const activityProgressPercentage = (completedActs / 4) * 100;

  // Helper Component for Activity Card
  const ActivityCard = ({ 
      view, 
      title, 
      desc, 
      difficulty, 
      icon: Icon, 
      colorClass, 
      isCompleted,
      progressKey
  }: { 
      view: ViewState, 
      title: string, 
      desc: string, 
      difficulty: string, 
      icon: any, 
      colorClass: string,
      isCompleted: boolean,
      progressKey: string
  }) => {
      // Check Prerequisite
      const requiredLessonId = ACTIVITY_PREREQUISITES[view];
      const requiredLesson = LESSONS.find(l => l.id === requiredLessonId);
      const isPrereqMet = requiredLesson ? userProgress.lessons[requiredLessonId]?.completed : true;

      return (
        <div 
            onClick={() => setCurrentView(view)}
            className="bg-cyber-800 border border-cyber-700 p-6 rounded-2xl cursor-pointer hover:border-cyber-accent hover:bg-cyber-800/80 transition group relative overflow-hidden flex flex-col"
        >
            <div className="absolute top-0 right-0 p-1 px-3 bg-cyber-900 rounded-bl-lg text-[10px] text-slate-400">{difficulty}</div>
            
            <div className={`${colorClass} w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition`}>
                <Icon />
            </div>
            
            <h3 className="text-lg font-bold text-white mb-2">{title}</h3>
            <p className="text-sm text-slate-400 mb-4 flex-grow">{desc}</p>
            
            <div className="mt-auto space-y-2">
                {isCompleted && (
                    <div className="text-emerald-500 text-xs font-bold flex items-center gap-1">
                        <ShieldCheck size={12}/> مكتمل
                    </div>
                )}
                
                {!isPrereqMet && requiredLesson && (
                    <div className="text-yellow-500 text-xs bg-yellow-500/10 p-2 rounded flex items-start gap-1">
                        <AlertTriangle size={12} className="mt-0.5 shrink-0" />
                        <span>ينصح بدراسة درس "{requiredLesson.title}" أولاً.</span>
                    </div>
                )}
            </div>
        </div>
      );
  };

  const renderContent = () => {
    switch (currentView) {
      case 'HOME':
        return (
          <div className="container mx-auto px-4 py-8 animate-fade-in">
            {/* Hero Section */}
            <div className="text-center mb-16 py-12 relative">
               <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyber-accent/10 rounded-full blur-[100px] -z-10"></div>
               <h2 className="text-4xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyber-accent to-emerald-400 mb-6 leading-relaxed py-2">
                 احمِ نفسك في العالم الرقمي
               </h2>
               <p className="text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
                 تعلم أساسيات الأمن السيبراني من خلال دروس تفاعلية، اختبارات عملية، ومحاكاة للهجمات الواقعية.
               </p>

               {/* Trackers Row */}
               <div className="flex flex-col md:flex-row gap-6 justify-center mt-10 max-w-3xl mx-auto">
                    {/* Lessons Tracker */}
                    <div className="flex-1 bg-cyber-800/50 p-4 rounded-xl border border-cyber-700">
                        <div className="flex justify-between text-xs text-slate-400 mb-2">
                            <span>مسار الدروس</span>
                            <span>{Math.round(progressPercentage)}%</span>
                        </div>
                        <div className="h-2 bg-cyber-900 rounded-full overflow-hidden">
                            <div className="h-full bg-cyber-accent transition-all duration-1000" style={{ width: `${progressPercentage}%` }}></div>
                        </div>
                    </div>

                    {/* Activities Tracker */}
                    <div className="flex-1 bg-cyber-800/50 p-4 rounded-xl border border-cyber-700">
                        <div className="flex justify-between text-xs text-slate-400 mb-2">
                            <span>الأنشطة المهارية</span>
                            <span>{Math.round(activityProgressPercentage)}%</span>
                        </div>
                        <div className="h-2 bg-cyber-900 rounded-full overflow-hidden">
                            <div className="h-full bg-purple-500 transition-all duration-1000" style={{ width: `${activityProgressPercentage}%` }}></div>
                        </div>
                    </div>
               </div>
            </div>

            {/* Lessons Grid */}
            <h3 className="text-2xl font-bold text-white mb-6 border-r-4 border-cyber-accent pr-4">مسار التعلم الأكاديمي</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
              {LESSONS.map((lesson, index) => {
                const prevLesson = LESSONS[index - 1];
                const isLocked = index > 0 && !userProgress.lessons[prevLesson?.id]?.completed;

                return (
                  <LessonCard
                    key={lesson.id}
                    lesson={lesson}
                    progress={userProgress.lessons}
                    onClick={() => handleLessonSelect(lesson.id, isLocked)}
                    index={index}
                    isLocked={isLocked}
                  />
                )
              })}
            </div>

            {/* Activities Section */}
            <h3 className="text-2xl font-bold text-white mb-6 border-r-4 border-purple-500 pr-4">المختبرات والأنشطة التفاعلية</h3>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
                <ActivityCard 
                    view="ACTIVITY_PHISHING"
                    title="محاكي التصيد"
                    desc="كشف الرسائل الاحتيالية."
                    difficulty="متوسط"
                    icon={Zap}
                    colorClass="bg-purple-900/30 text-purple-400"
                    isCompleted={userProgress.activities.phishing}
                    progressKey="phishing"
                />
                
                <ActivityCard 
                    view="ACTIVITY_NETWORK"
                    title="محلل الشبكة"
                    desc="اكتشاف الثغرات وإصلاحها."
                    difficulty="متوسط/صعب"
                    icon={LayoutGrid}
                    colorClass="bg-emerald-900/30 text-emerald-400"
                    isCompleted={userProgress.activities.network}
                    progressKey="network"
                />

                <ActivityCard 
                    view="ACTIVITY_CRYPTO"
                    title="مختبر التشفير"
                    desc="فك الشفرات والهاش."
                    difficulty="صعب"
                    icon={Lock}
                    colorClass="bg-blue-900/30 text-blue-400"
                    isCompleted={userProgress.activities.crypto}
                    progressKey="crypto"
                />

                <ActivityCard 
                    view="ACTIVITY_ACCESS"
                    title="مصفوفة الصلاحيات"
                    desc="تطبيق مبدأ أقل الامتيازات."
                    difficulty="صعب جداً"
                    icon={Shield}
                    colorClass="bg-yellow-900/30 text-yellow-400"
                    isCompleted={userProgress.activities.access}
                    progressKey="access"
                />
            </div>
          </div>
        );

      case 'LESSON':
        const lesson = LESSONS.find(l => l.id === selectedLessonId);
        if (!lesson) return null;
        return (
          <LessonView
            lesson={lesson}
            progress={userProgress.lessons}
            onUpdateProgress={updateLessonProgress}
            onExit={() => setCurrentView('HOME')}
          />
        );

      case 'DASHBOARD':
        return <Dashboard progress={userProgress} />;

      case 'ACTIVITY_PHISHING':
        return (
            <div className="animate-fade-in">
                 <button onClick={() => setCurrentView('HOME')} className="container mx-auto px-4 mt-8 text-slate-400 hover:text-white flex items-center gap-2"><span className="text-2xl">&larr;</span> خروج</button>
                 <PhishingSimulator />
            </div>
        );
      
      case 'ACTIVITY_NETWORK':
        return (
            <div className="animate-fade-in">
                 <button onClick={() => setCurrentView('HOME')} className="container mx-auto px-4 mt-8 text-slate-400 hover:text-white flex items-center gap-2"><span className="text-2xl">&larr;</span> خروج</button>
                 <NetworkAnalyzer />
            </div>
        );

      case 'ACTIVITY_CRYPTO':
        return (
             <div className="animate-fade-in">
                 <button onClick={() => setCurrentView('HOME')} className="container mx-auto px-4 mt-8 text-slate-400 hover:text-white flex items-center gap-2"><span className="text-2xl">&larr;</span> خروج</button>
                 <CryptoLab onComplete={() => completeActivity('crypto')} />
            </div>
        );

      case 'ACTIVITY_ACCESS':
        return (
             <div className="animate-fade-in">
                 <button onClick={() => setCurrentView('HOME')} className="container mx-auto px-4 mt-8 text-slate-400 hover:text-white flex items-center gap-2"><span className="text-2xl">&larr;</span> خروج</button>
                 <AccessControl onComplete={() => completeActivity('access')} />
            </div>
        );

      default:
        return <div>Not found</div>;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans">
      <Header currentView={currentView} setView={setCurrentView} />
      <main className="flex-grow">
        {renderContent()}
      </main>
      <Footer />
    </div>
  );
};

export default App;
